package com.cg.DemoJava;

public interface IExchangeService {
	public double getExchangeRate();

}
