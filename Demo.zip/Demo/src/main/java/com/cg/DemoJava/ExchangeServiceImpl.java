package com.cg.DemoJava;

public class ExchangeServiceImpl implements IExchangeService {
	private double exchangeRate;


	/*public void setExchangeRate(double exchangeRate) {
		exchangeRate = exchangeRate;
	}*/

	public ExchangeServiceImpl(double exchangeRate) {

		this.exchangeRate = exchangeRate;
	}
	

	public double getExchangeRate() {
		return exchangeRate;
	}

}
