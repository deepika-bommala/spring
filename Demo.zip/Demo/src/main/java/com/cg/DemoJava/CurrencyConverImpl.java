package com.cg.DemoJava;

public class CurrencyConverImpl implements ICurrencyConverter {
	private IExchangeService exchangeService;

	public CurrencyConverImpl() {
		// super();
		System.out.println("CurrencyConverImpl()");

	}

	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRupees()");
		return dollars * exchangeService.getExchangeRate();
	}

	public IExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(IExchangeService exchangeService) {
		System.out.println("setExchangeRate");
		this.exchangeService = exchangeService;
	}

}
