package com.cg.DemoJava;

public interface ICurrencyConverter {
	public double dollarsToRupees(double dollars);
	

}
